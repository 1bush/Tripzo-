# Tripzio — Android APK Project

Ky folder është gati për ta hapur në **Android Studio** dhe për të krijuar APK.

## Si ta kthesh në APK

1. Hap Android Studio.
2. Zgjidh **Open** dhe hap folderin `Tripzio_APK_Project`.
3. Prit derisa Gradle të bëjë sync.
4. Shko te **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK del te:
   `app/build/outputs/apk/debug/app-debug.apk`

## Për release APK

1. Android Studio: **Build > Generate Signed Bundle / APK**.
2. Zgjidh **APK**.
3. Krijo ose zgjidh një keystore.
4. Zgjidh variantin **release**.

## Shënim për AI

Aplikacioni është futur në WebView si HTML lokal. UI punon si app Android.
Për AI real me Anthropic/Claude duhet një backend server ose API key i sigurt. Mos e vendos API key direkt në HTML për publikim.

## Paketa

- Application ID: `com.tripzio.app`
- Version: `1.0.0`
- Min SDK: 23
- Target SDK: 35
